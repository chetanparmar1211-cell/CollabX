export interface User {
  id: string;
  email: string;
  name: string;
  role: 'brand' | 'reviewer' | 'admin';
  avatar?: string;
  isVerified: boolean;
  createdAt: string;
  // Brand specific
  companyName?: string;
  // Reviewer specific
  amazonProfile?: string;
  categories?: string[];
  rating?: number;
  completedReviews?: number;
}

export interface Campaign {
  id: string;
  brandId: string;
  brandName: string;
  productName: string;
  amazonUrl: string;
  productImages: string[];
  reviewsRequired: number;
  reviewsCompleted: number;
  compensation: number;
  compensationType: 'cash' | 'refund' | 'both';
  deadline: string;
  status: 'active' | 'completed' | 'pending' | 'paused';
  description: string;
  requirements: string[];
  category: string;
  createdAt: string;
  updatedAt: string;
}

export interface Review {
  id: string;
  campaignId: string;
  reviewerId: string;
  reviewerName: string;
  amazonOrderId: string;
  amazonReviewUrl: string;
  screenshot: string;
  status: 'pending' | 'approved' | 'rejected' | 'flagged';
  submittedAt: string;
  verifiedAt?: string;
  notes?: string;
}

export interface Wallet {
  id: string;
  userId: string;
  balance: number;
  pendingBalance: number;
  totalEarnings: number;
  totalSpent: number;
  transactions: Transaction[];
}

export interface Transaction {
  id: string;
  walletId: string;
  type: 'credit' | 'debit' | 'commission' | 'withdrawal';
  amount: number;
  description: string;
  status: 'pending' | 'completed' | 'failed';
  createdAt: string;
  relatedCampaignId?: string;
}

export interface Application {
  id: string;
  campaignId: string;
  reviewerId: string;
  reviewerName: string;
  reviewerRating: number;
  status: 'pending' | 'approved' | 'rejected';
  appliedAt: string;
  message?: string;
}