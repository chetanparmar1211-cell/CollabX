import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  Plus,
  TrendingUp,
  Users,
  Star,
  DollarSign,
  Eye,
  AlertCircle,
  Calendar,
  ArrowUpRight
} from 'lucide-react';

const BrandDashboard = () => {
  const stats = [
    {
      title: 'Active Campaigns',
      value: '12',
      change: '+2 this week',
      changeType: 'positive',
      icon: TrendingUp
    },
    {
      title: 'Total Reviews',
      value: '348',
      change: '+45 this month',
      changeType: 'positive',
      icon: Star
    },
    {
      title: 'Active Reviewers',
      value: '89',
      change: '+12 this week',
      changeType: 'positive',
      icon: Users
    },
    {
      title: 'Total Spent',
      value: '₹42,850',
      change: '+₹5,200 this month',
      changeType: 'neutral',
      icon: DollarSign
    }
  ];

  const recentCampaigns = [
    {
      id: '1',
      productName: 'Wireless Bluetooth Headphones Pro',
      status: 'active',
      progress: 75,
      reviewsCompleted: 15,
      reviewsRequired: 20,
      daysLeft: 5,
      budget: '₹8,000'
    },
    {
      id: '2',
      productName: 'Smart Fitness Tracker',
      status: 'active',
      progress: 40,
      reviewsCompleted: 8,
      reviewsRequired: 20,
      daysLeft: 12,
      budget: '₹6,000'
    },
    {
      id: '3',
      productName: 'Organic Protein Powder',
      status: 'completed',
      progress: 100,
      reviewsCompleted: 25,
      reviewsRequired: 25,
      daysLeft: 0,
      budget: '₹10,000'
    },
    {
      id: '4',
      productName: 'LED Desk Lamp with USB',
      status: 'pending',
      progress: 0,
      reviewsCompleted: 0,
      reviewsRequired: 15,
      daysLeft: 14,
      budget: '₹4,500'
    }
  ];

  const pendingReviews = [
    {
      id: '1',
      reviewer: 'Sarah M.',
      rating: 4.9,
      product: 'Wireless Headphones Pro',
      submittedAt: '2 hours ago',
      screenshot: 'Available'
    },
    {
      id: '2', 
      reviewer: 'Mike R.',
      rating: 4.7,
      product: 'Smart Fitness Tracker',
      submittedAt: '5 hours ago',
      screenshot: 'Available'
    },
    {
      id: '3',
      reviewer: 'Emma L.',
      rating: 4.8,
      product: 'Organic Protein Powder',
      submittedAt: '1 day ago',
      screenshot: 'Available'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'paused': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Brand Dashboard</h1>
          <p className="text-gray-600 mt-1">Monitor your review campaigns and performance</p>
        </div>
        <Button asChild className="flex items-center space-x-2">
          <Link to="/campaigns/create">
            <Plus className="h-4 w-4 mr-2" />
            New Campaign
          </Link>
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                    <p className={`text-sm mt-1 ${
                      stat.changeType === 'positive' ? 'text-green-600' : 
                      stat.changeType === 'negative' ? 'text-red-600' : 'text-gray-600'
                    }`}>
                      {stat.change}
                    </p>
                  </div>
                  <div className={`p-3 rounded-lg ${
                    stat.changeType === 'positive' ? 'bg-green-100' : 'bg-blue-100'
                  }`}>
                    <Icon className={`h-6 w-6 ${
                      stat.changeType === 'positive' ? 'text-green-600' : 'text-blue-600'
                    }`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Campaigns */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Recent Campaigns</CardTitle>
                <CardDescription>Your latest review campaigns</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to="/campaigns">View All</Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentCampaigns.map((campaign) => (
                  <div key={campaign.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900 mb-1">{campaign.productName}</h3>
                        <div className="flex items-center space-x-3 text-sm text-gray-600">
                          <Badge variant="secondary" className={getStatusColor(campaign.status)}>
                            {campaign.status}
                          </Badge>
                          <span>{campaign.reviewsCompleted}/{campaign.reviewsRequired} reviews</span>
                          <span>{campaign.daysLeft} days left</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">{campaign.budget}</p>
                        <p className="text-xs text-gray-500">Budget</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Progress value={campaign.progress} className="flex-1" />
                      <span className="text-sm text-gray-600 min-w-0">{campaign.progress}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Pending Reviews */}
        <div>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center space-x-2">
                  <span>Pending Reviews</span>
                  <Badge variant="destructive" className="ml-2">
                    {pendingReviews.length}
                  </Badge>
                </CardTitle>
                <CardDescription>Reviews waiting for verification</CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pendingReviews.map((review) => (
                  <div key={review.id} className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="font-medium text-gray-900 text-sm">{review.reviewer}</p>
                        <div className="flex items-center space-x-1 mt-1">
                          <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                          <span className="text-xs text-gray-600">{review.rating}</span>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {review.screenshot}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600 mb-2">{review.product}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{review.submittedAt}</span>
                      <Button size="sm" variant="outline" className="text-xs h-6 px-2">
                        Review
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" className="w-full mt-4" asChild>
                <Link to="/reviews">View All Reviews</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks and shortcuts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2" asChild>
              <Link to="/campaigns/create">
                <Plus className="h-6 w-6" />
                <span>Create Campaign</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2" asChild>
              <Link to="/reviewers">
                <Users className="h-6 w-6" />
                <span>Browse Reviewers</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2" asChild>
              <Link to="/analytics">
                <TrendingUp className="h-6 w-6" />
                <span>View Analytics</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2" asChild>
              <Link to="/wallet">
                <DollarSign className="h-6 w-6" />
                <span>Manage Wallet</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BrandDashboard;