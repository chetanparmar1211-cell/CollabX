import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DollarSign,
  Star,
  TrendingUp,
  Clock,
  Search,
  Upload,
  CheckCircle,
  AlertCircle,
  Calendar,
  Wallet
} from 'lucide-react';

const ReviewerDashboard = () => {
  const stats = [
    {
      title: 'Total Earnings',
      value: '₹12,450',
      change: '+₹2,340 this month',
      changeType: 'positive',
      icon: DollarSign
    },
    {
      title: 'Reviews Completed',
      value: '45',
      change: '+8 this month',
      changeType: 'positive',
      icon: Star
    },
    {
      title: 'Success Rate',
      value: '98.2%',
      change: '+2.1% improvement',
      changeType: 'positive',
      icon: TrendingUp
    },
    {
      title: 'Pending Reviews',
      value: '3',
      change: 'Due in 2 days',
      changeType: 'neutral',
      icon: Clock
    }
  ];

  const activeReviews = [
    {
      id: '1',
      campaignId: 'camp_1',
      productName: 'Wireless Bluetooth Headphones Pro',
      brandName: 'TechGear',
      compensation: '₹450',
      deadline: '2024-08-18',
      status: 'purchased',
      progress: 50,
      nextStep: 'Submit Review',
      daysLeft: 4
    },
    {
      id: '2',
      campaignId: 'camp_2',
      productName: 'Smart Fitness Tracker',
      brandName: 'FitLife',
      compensation: '₹380',
      deadline: '2024-08-20',
      status: 'reviewing',
      progress: 25,
      nextStep: 'Purchase Product',
      daysLeft: 6
    },
    {
      id: '3',
      campaignId: 'camp_3',
      productName: 'Organic Protein Powder',
      brandName: 'HealthPlus',
      compensation: '₹520',
      deadline: '2024-08-16',
      status: 'submitted',
      progress: 90,
      nextStep: 'Awaiting Verification',
      daysLeft: 2
    }
  ];

  const availableCampaigns = [
    {
      id: '1',
      productName: 'LED Desk Lamp with USB Charging',
      brandName: 'ModernWork',
      category: 'Electronics',
      compensation: '₹350',
      reviewsNeeded: 8,
      totalReviews: 15,
      rating: 4.5,
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop'
    },
    {
      id: '2',
      productName: 'Organic Green Tea Bags',
      brandName: 'NaturalTea',
      category: 'Health',
      compensation: '₹280',
      reviewsNeeded: 12,
      totalReviews: 20,
      rating: 4.3,
      imageUrl: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?w=64&h=64&fit=crop'
    },
    {
      id: '3',
      productName: 'Waterproof Phone Case',
      brandName: 'SafeGuard',
      category: 'Accessories',
      compensation: '₹420',
      reviewsNeeded: 5,
      totalReviews: 12,
      rating: 4.7,
      imageUrl: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=64&h=64&fit=crop'
    }
  ];

  const recentEarnings = [
    {
      id: '1',
      productName: 'Bluetooth Speaker',
      amount: '₹380',
      date: '2024-08-12',
      status: 'completed'
    },
    {
      id: '2',
      productName: 'Yoga Mat Premium',
      amount: '₹450',
      date: '2024-08-10',
      status: 'completed'
    },
    {
      id: '3',
      productName: 'Coffee Beans Arabica',
      amount: '₹320',
      date: '2024-08-08',
      status: 'completed'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'purchased': return 'bg-blue-100 text-blue-800';
      case 'reviewing': return 'bg-yellow-100 text-yellow-800';
      case 'submitted': return 'bg-purple-100 text-purple-800';
      case 'completed': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reviewer Dashboard</h1>
          <p className="text-gray-600 mt-1">Track your reviews and earnings</p>
        </div>
        <div className="flex space-x-3">
          <Button variant="outline" asChild>
            <Link to="/wallet" className="flex items-center space-x-2">
              <Wallet className="h-4 w-4" />
              <span>Wallet</span>
            </Link>
          </Button>
          <Button asChild>
            <Link to="/campaigns/discover" className="flex items-center space-x-2">
              <Search className="h-4 w-4" />
              <span>Find Campaigns</span>
            </Link>
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                    <p className={`text-sm mt-1 ${
                      stat.changeType === 'positive' ? 'text-green-600' : 
                      stat.changeType === 'negative' ? 'text-red-600' : 'text-gray-600'
                    }`}>
                      {stat.change}
                    </p>
                  </div>
                  <div className={`p-3 rounded-lg ${
                    stat.changeType === 'positive' ? 'bg-green-100' : 'bg-blue-100'
                  }`}>
                    <Icon className={`h-6 w-6 ${
                      stat.changeType === 'positive' ? 'text-green-600' : 'text-blue-600'
                    }`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Active Reviews */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Active Reviews</CardTitle>
                <CardDescription>Your current review assignments</CardDescription>
              </div>
              <Button variant="outline" size="sm" asChild>
                <Link to="/reviews/active">View All</Link>
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {activeReviews.map((review) => (
                  <div key={review.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900 mb-1">{review.productName}</h3>
                        <div className="flex items-center space-x-3 text-sm text-gray-600">
                          <Badge variant="secondary" className={getStatusColor(review.status)}>
                            {review.status}
                          </Badge>
                          <span>{review.brandName}</span>
                          <span>{review.daysLeft} days left</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-green-600">{review.compensation}</p>
                        <p className="text-xs text-gray-500">Reward</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-gray-600">Next: {review.nextStep}</span>
                      <span className="text-sm text-gray-600">{review.progress}%</span>
                    </div>
                    <Progress value={review.progress} className="mb-3" />
                    <div className="flex justify-end">
                      <Button size="sm" variant="outline">
                        Continue
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Available Campaigns */}
        <div>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Available Campaigns</CardTitle>
                <CardDescription>New opportunities for you</CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {availableCampaigns.map((campaign) => (
                  <div key={campaign.id} className="border rounded-lg p-3 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start space-x-3 mb-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={campaign.imageUrl} />
                        <AvatarFallback>{campaign.productName[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-900 text-sm line-clamp-2 mb-1">
                          {campaign.productName}
                        </h4>
                        <div className="flex items-center space-x-2 text-xs text-gray-600">
                          <Badge variant="outline" className="text-xs">
                            {campaign.category}
                          </Badge>
                          <div className="flex items-center space-x-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span>{campaign.rating}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm font-medium text-green-600">{campaign.compensation}</span>
                      <span className="text-xs text-gray-500">
                        {campaign.reviewsNeeded}/{campaign.totalReviews} needed
                      </span>
                    </div>
                    <Button size="sm" className="w-full">
                      Apply Now
                    </Button>
                  </div>
                ))}
              </div>
              <Button variant="outline" size="sm" className="w-full mt-4" asChild>
                <Link to="/campaigns/discover">Browse All Campaigns</Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Earnings */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Recent Earnings</CardTitle>
            <CardDescription>Your latest completed reviews</CardDescription>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link to="/wallet">View Wallet</Link>
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentEarnings.map((earning) => (
              <div key={earning.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <p className="font-medium text-gray-900 text-sm">{earning.productName}</p>
                    <p className="text-xs text-gray-600">{earning.date}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-green-600">{earning.amount}</p>
                  <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                    {earning.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks and shortcuts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2" asChild>
              <Link to="/campaigns/discover">
                <Search className="h-6 w-6" />
                <span>Find Campaigns</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2" asChild>
              <Link to="/reviews/submit">
                <Upload className="h-6 w-6" />
                <span>Submit Review</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2" asChild>
              <Link to="/wallet">
                <Wallet className="h-6 w-6" />
                <span>Check Earnings</span>
              </Link>
            </Button>
            <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2" asChild>
              <Link to="/profile">
                <Star className="h-6 w-6" />
                <span>Update Profile</span>
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReviewerDashboard;