import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import DashboardLayout from '@/components/Layout/DashboardLayout';
import { ArrowLeft, Upload, Plus, X } from 'lucide-react';

const CreateCampaign = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    productName: '',
    amazonUrl: '',
    productImages: [] as string[],
    reviewsRequired: '',
    compensation: '',
    compensationType: 'cash',
    deadline: '',
    description: '',
    requirements: [] as string[],
    category: ''
  });
  const [newRequirement, setNewRequirement] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock campaign creation
    console.log('Creating campaign:', formData);
    navigate('/campaigns');
  };

  const addRequirement = () => {
    if (newRequirement.trim()) {
      setFormData(prev => ({
        ...prev,
        requirements: [...prev.requirements, newRequirement.trim()]
      }));
      setNewRequirement('');
    }
  };

  const removeRequirement = (index: number) => {
    setFormData(prev => ({
      ...prev,
      requirements: prev.requirements.filter((_, i) => i !== index)
    }));
  };

  const categories = [
    'Electronics', 'Home & Garden', 'Fashion', 'Beauty', 'Sports', 
    'Books', 'Toys', 'Health', 'Automotive', 'Kitchen'
  ];

  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/campaigns" className="flex items-center">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Campaigns
            </Link>
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Create New Campaign</h1>
            <p className="text-gray-600">Launch a new Amazon review campaign</p>
          </div>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle>Basic Information</CardTitle>
                  <CardDescription>
                    Enter your product details and campaign information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="productName">Product Name *</Label>
                    <Input
                      id="productName"
                      placeholder="Wireless Bluetooth Headphones Pro"
                      value={formData.productName}
                      onChange={(e) => setFormData(prev => ({ ...prev, productName: e.target.value }))}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amazonUrl">Amazon Product URL *</Label>
                    <Input
                      id="amazonUrl"
                      type="url"
                      placeholder="https://amazon.in/dp/..."
                      value={formData.amazonUrl}
                      onChange={(e) => setFormData(prev => ({ ...prev, amazonUrl: e.target.value }))}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Product Category *</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category.toLowerCase()}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Product Description</Label>
                    <Textarea
                      id="description"
                      placeholder="Describe your product and what makes it special..."
                      rows={4}
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Campaign Settings */}
              <Card>
                <CardHeader>
                  <CardTitle>Campaign Settings</CardTitle>
                  <CardDescription>
                    Configure your review requirements and timeline
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="reviewsRequired">Reviews Required *</Label>
                      <Input
                        id="reviewsRequired"
                        type="number"
                        min="1"
                        max="100"
                        placeholder="20"
                        value={formData.reviewsRequired}
                        onChange={(e) => setFormData(prev => ({ ...prev, reviewsRequired: e.target.value }))}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="deadline">Campaign Deadline *</Label>
                      <Input
                        id="deadline"
                        type="date"
                        value={formData.deadline}
                        onChange={(e) => setFormData(prev => ({ ...prev, deadline: e.target.value }))}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="compensation">Compensation per Review *</Label>
                      <Input
                        id="compensation"
                        type="number"
                        min="100"
                        placeholder="500"
                        value={formData.compensation}
                        onChange={(e) => setFormData(prev => ({ ...prev, compensation: e.target.value }))}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="compensationType">Compensation Type</Label>
                      <Select value={formData.compensationType} onValueChange={(value) => setFormData(prev => ({ ...prev, compensationType: value }))}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cash">Cash Payment</SelectItem>
                          <SelectItem value="refund">Product Refund</SelectItem>
                          <SelectItem value="both">Cash + Refund</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Requirements */}
              <Card>
                <CardHeader>
                  <CardTitle>Review Requirements</CardTitle>
                  <CardDescription>
                    Specify what reviewers need to do
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="e.g., Include product photos in review"
                      value={newRequirement}
                      onChange={(e) => setNewRequirement(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addRequirement())}
                    />
                    <Button type="button" onClick={addRequirement}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    {formData.requirements.map((req, index) => (
                      <Badge key={index} variant="secondary" className="mr-2 mb-2">
                        {req}
                        <button
                          type="button"
                          onClick={() => removeRequirement(index)}
                          className="ml-2 hover:text-red-600"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>

                  {formData.requirements.length === 0 && (
                    <p className="text-sm text-gray-500">
                      Add specific requirements for reviewers (optional)
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Campaign Preview */}
              <Card>
                <CardHeader>
                  <CardTitle>Campaign Preview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="aspect-square bg-gray-100 rounded-lg flex items-center justify-center">
                    <Upload className="h-8 w-8 text-gray-400" />
                  </div>
                  
                  <div>
                    <h3 className="font-medium text-gray-900">
                      {formData.productName || 'Product Name'}
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">
                      {formData.category || 'Category'}
                    </p>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Reviews needed:</span>
                      <span className="font-medium">{formData.reviewsRequired || '0'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Compensation:</span>
                      <span className="font-medium text-green-600">
                        ₹{formData.compensation || '0'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total budget:</span>
                      <span className="font-medium">
                        ₹{(parseInt(formData.compensation || '0') * parseInt(formData.reviewsRequired || '0')).toLocaleString()}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Actions */}
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <Button type="submit" className="w-full">
                      Create Campaign
                    </Button>
                    <Button type="button" variant="outline" className="w-full">
                      Save as Draft
                    </Button>
                  </div>
                  
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                    <p className="text-xs text-blue-800">
                      <strong>Note:</strong> Your campaign will be reviewed by our team before going live. This usually takes 2-4 hours.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </div>
    </DashboardLayout>
  );
};

export default CreateCampaign;