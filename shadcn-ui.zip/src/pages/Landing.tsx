import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Star,
  Users,
  Shield,
  TrendingUp,
  ArrowRight,
  CheckCircle,
  Zap,
  Globe,
  Target
} from 'lucide-react';

const Landing = () => {
  const features = [
    {
      icon: Target,
      title: 'Smart Campaign Management',
      description: 'Create, manage, and track Amazon review campaigns with intelligent matching algorithms.'
    },
    {
      icon: Users,
      title: 'Verified Reviewer Network',
      description: 'Access thousands of verified reviewers across all product categories.'
    },
    {
      icon: Shield,
      title: 'Fraud Protection',
      description: 'Advanced AI-powered fraud detection ensures authentic reviews and protects your brand.'
    },
    {
      icon: Zap,
      title: 'Instant Payouts',
      description: 'Reviewers get paid instantly upon review verification through our secure wallet system.'
    },
    {
      icon: TrendingUp,
      title: 'Real-time Analytics',
      description: 'Track campaign performance, ROI, and review metrics in real-time dashboards.'
    },
    {
      icon: Globe,
      title: 'Global Reach',
      description: 'Scale your review campaigns across multiple Amazon marketplaces worldwide.'
    }
  ];

  const stats = [
    { label: 'Active Campaigns', value: '2,500+', growth: '+23%' },
    { label: 'Verified Reviewers', value: '15,000+', growth: '+45%' },
    { label: 'Reviews Generated', value: '50,000+', growth: '+67%' },
    { label: 'Success Rate', value: '98.5%', growth: '+2%' }
  ];

  const testimonials = [
    {
      name: 'Sarah Chen',
      role: 'E-commerce Manager',
      company: 'TechGear Pro',
      content: 'Frapp Reviews transformed our product launch strategy. We went from 0 to 200 verified reviews in just 2 weeks.',
      avatar: '/images/Success.jpg'
    },
    {
      name: 'Marcus Rodriguez',
      role: 'Top Reviewer',
      content: 'As a reviewer, I love the transparent process and instant payments. Made over $2,000 in my first month!',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=64&h=64&fit=crop&crop=face'
    },
    {
      name: 'Emma Thompson',
      role: 'Brand Owner',
      company: 'Organic Beauty Co.',
      content: 'The fraud protection gives me confidence that every review is authentic. ROI has been incredible.',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=64&h=64&fit=crop&crop=face'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">F</span>
              </div>
              <span className="text-xl font-bold text-gray-900">Frapp Reviews</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" asChild>
                <Link to="/login">Login</Link>
              </Button>
              <Button asChild>
                <Link to="/signup">Get Started</Link>
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <Badge variant="secondary" className="mb-6 bg-blue-100 text-blue-800">
              🚀 Now live on Amazon marketplace
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Scale Your Amazon
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">
                {' '}Review Strategy
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Connect with verified reviewers, launch authentic review campaigns, and boost your product visibility 
              with our commission-based platform trusted by thousands of brands.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button size="lg" className="text-lg px-8 py-3" asChild>
                <Link to="/signup" className="flex items-center">
                  Start Your Campaign
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button variant="outline" size="lg" className="text-lg px-8 py-3" asChild>
                <Link to="/signup?role=reviewer">
                  Become a Reviewer
                </Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                  <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
                  <div className="text-sm text-gray-600 mb-2">{stat.label}</div>
                  <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs">
                    {stat.growth} this month
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Everything you need to scale reviews
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From campaign creation to fraud protection, we've built the most comprehensive 
              review management platform for Amazon sellers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                  <CardHeader className="pb-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center mb-4">
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-xl font-semibold">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-gray-600 leading-relaxed">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              How Frapp Reviews Works
            </h2>
            <p className="text-xl text-gray-600">
              Simple, transparent, and effective in just 4 steps
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: '01',
                title: 'Create Campaign',
                description: 'Upload product details, set requirements, and fund your campaign wallet.'
              },
              {
                step: '02',
                title: 'Match Reviewers',
                description: 'Our algorithm matches your product with verified reviewers in your category.'
              },
              {
                step: '03',
                title: 'Review Submission',
                description: 'Reviewers purchase, test, and submit authentic reviews with proof.'
              },
              {
                step: '04',
                title: 'Verification & Payment',
                description: 'We verify reviews and process payments automatically.'
              }
            ].map((step, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-white font-bold text-lg">{step.step}</span>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Trusted by thousands of brands and reviewers
            </h2>
            <p className="text-xl text-gray-600">
              See what our community has to say about Frapp Reviews
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-700 mb-6 leading-relaxed">"{testimonial.content}"</p>
                  <div className="flex items-center space-x-3">
                    <img 
                      src={testimonial.avatar} 
                      alt={testimonial.name}
                      className="w-10 h-10 rounded-full"
                    />
                    <div>
                      <p className="font-semibold text-gray-900">{testimonial.name}</p>
                      <p className="text-sm text-gray-600">
                        {testimonial.role}
                        {testimonial.company && ` at ${testimonial.company}`}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Ready to scale your Amazon reviews?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of successful brands and reviewers on the most trusted review platform.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="text-lg px-8 py-3" asChild>
              <Link to="/signup">
                Start Your First Campaign
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 py-3 text-white border-white hover:bg-white hover:text-blue-600" asChild>
              <Link to="/signup?role=reviewer">
                Join as Reviewer
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">F</span>
                </div>
                <span className="text-xl font-bold">Frapp Reviews</span>
              </div>
              <p className="text-gray-400">
                The most trusted platform for Amazon review campaigns.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">For Brands</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/campaigns" className="hover:text-white">Create Campaign</Link></li>
                <li><Link to="/reviewers" className="hover:text-white">Find Reviewers</Link></li>
                <li><Link to="/analytics" className="hover:text-white">Analytics</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">For Reviewers</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/campaigns/discover" className="hover:text-white">Find Campaigns</Link></li>
                <li><Link to="/wallet" className="hover:text-white">Earnings</Link></li>
                <li><Link to="/profile" className="hover:text-white">Profile</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/help" className="hover:text-white">Help Center</Link></li>
                <li><Link to="/contact" className="hover:text-white">Contact Us</Link></li>
                <li><Link to="/terms" className="hover:text-white">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Frapp Reviews. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;